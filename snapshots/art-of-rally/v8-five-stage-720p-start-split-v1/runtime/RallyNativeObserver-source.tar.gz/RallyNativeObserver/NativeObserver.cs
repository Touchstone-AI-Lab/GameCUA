// Read-only development observer; it never changes native game fields or sends inputs.
using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;

[BepInPlugin("org.touchstone.artofrally.observer", "Art of Rally Native Observer", "0.2.0")]
public sealed class NativeObserver : BaseUnityPlugin
{
    static readonly BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
    static StreamWriter output;
    static int sequence;
    static Assembly game;
    static string binding;
    static string lastSignature;
    static double lastEmitted;
    string auditPath;
    float auditAt;

    [Serializable]
    public sealed class StageIdentity
    {
        public int area;
        public string stage;
        public string scene;
        public string weather;
        public bool forward;
    }

    [Serializable]
    public sealed class Sample
    {
        public int schema_version = 1;
        public string sampling = "native_changes_with_one_second_heartbeat";
        public string binding;
        public int sequence;
        public string source;
        public double utc_seconds;
        public double monotonic_seconds;
        public float unity_time;
        public float delta_time;
        public float fixed_time;
        public float maximum_delta_time;
        public int status;
        public string mode;
        public string stage;
        public string scene;
        public string weather;
        public bool forward;
        public int stage_index;
        public int stage_count;
        [NonSerialized] public StageIdentity[] stage_plan;
        public string vehicle;
        public int current;
        public int start;
        public int last;
        public int count;
        public bool resetting;
        public bool debug;
        public bool finish_gate;
        public string stage_time;
        public string penalties;
        public string detected;
        public string terminal_damage;
        public long result_time_ms;
        public double result_time_seconds_native;
        public bool player_retired;
        public Vector3 position;
        public Vector3 velocity;
        public string error;
    }

    static object Field(object value, string name)
    {
        if (value == null) throw new InvalidOperationException("Missing native instance: " + name);
        FieldInfo f = value.GetType().GetField(name, Flags);
        if (f == null) throw new MissingFieldException(value.GetType().Name, name);
        return f.GetValue(value);
    }

    static string Serialize(Sample sample)
    {
        string raw = JsonUtility.ToJson(sample);
        string plan = sample.stage_plan == null ? "null" : "[" + String.Join(",", Array.ConvertAll(sample.stage_plan, stage => JsonUtility.ToJson(stage))) + "]";
        return raw.Substring(0, raw.Length - 1) + ",\"stage_plan\":" + plan + "}";
    }

    public static long ResultMilliseconds(object value, out double seconds)
    {
        if (value == null) throw new InvalidOperationException("Missing native result time");
        seconds = Convert.ToDouble(value, CultureInfo.InvariantCulture);
        if (Double.IsNaN(seconds) || Double.IsInfinity(seconds) || seconds < 0 || seconds >= Int64.MaxValue / 1000.0)
            throw new InvalidOperationException("Invalid native result time");
        return checked((long)Math.Floor(seconds * 1000.0));
    }

    static void ReadStageResult(Sample s)
    {
        Type gm = game.GetType("GameModeManager");
        s.mode = gm.GetField("GameMode",Flags).GetValue(null).ToString();
        object rally = gm.GetMethod("GetRallyDataCurrentGameMode",Flags).Invoke(null,null);
        object stage = rally.GetType().GetMethod("GetCurrentStage",Flags).Invoke(rally,null);
        s.stage_index = Convert.ToInt32(Field(rally,"CurrentStageIndex"));
        s.stage_count = Convert.ToInt32(Field(rally,"StageCount"));
        IList stages = (IList)Field(rally,"StageList");
        s.stage_plan = new StageIdentity[stages.Count];
        for (int i = 0; i < stages.Count; i++)
            s.stage_plan[i] = new StageIdentity {
                area = Convert.ToInt32(Field(stages[i],"Area")),
                stage = Field(stages[i],"Name").ToString(),
                scene = Field(stages[i],"SceneConstant").ToString(),
                weather = Field(stages[i],"Weather").ToString(),
                forward = Convert.ToBoolean(Field(stages[i],"IsForwardStage"))
            };
        s.stage = Field(stage,"Name").ToString();
        s.scene = Field(stage,"SceneConstant").ToString();
        s.weather = Field(stage,"Weather").ToString();
        s.forward = Convert.ToBoolean(Field(stage,"IsForwardStage"));
        object season = gm.GetMethod("GetSeasonDataCurrentGameMode",Flags).Invoke(null,null);
        s.vehicle = Field(Field(season,"SelectedCar"),"prefabName").ToString();
        IList drivers = (IList)Field(season,"DriverList");
        int playerCount = 0;
        foreach (object driver in drivers)
        {
            if (!Convert.ToBoolean(Field(driver,"isPlayer"))) continue;
            playerCount++;
            s.player_retired = Convert.ToBoolean(Field(driver,"hasRetiredThisStage"));
            IList results = (IList)Field(driver,"RallyResults");
            int rallyIndex = Convert.ToInt32(Field(season,"CurrentRallyIndex"));
            IList times = (IList)Field(results[rallyIndex],"StageTimes");
            int stageIndex = Convert.ToInt32(Field(rally,"CurrentStageIndex"));
            s.result_time_ms = ResultMilliseconds(times[stageIndex], out s.result_time_seconds_native);
        }
        if (playerCount != 1) throw new InvalidOperationException("Native result lacks unique player");
    }

    void Awake()
    {
        string path = Environment.GetEnvironmentVariable("GAMESCIENTIST_RALLY_OBSERVER");
        binding = Environment.GetEnvironmentVariable("GAMESCIENTIST_RALLY_BINDING");
        if (String.IsNullOrEmpty(path) || String.IsNullOrEmpty(binding)) return;
        output = new StreamWriter(new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.Read));
        output.AutoFlush = true;
        game = Assembly.Load("Assembly-CSharp");
        auditPath = Environment.GetEnvironmentVariable("GAMESCIENTIST_RALLY_RESULT_AUDIT");
        Harmony patcher = new Harmony("org.touchstone.artofrally.observer");
        foreach (string pair in new [] {"OutOfBoundsManager:FixedUpdate", "StageTimerManager:Update", "StageTimerManager:Reset", "StageSceneManager:SetRestartStage", "StageTimerManager:OnStageOver", "TimingGate:OnTriggerEnter"})
        {
            string[] parts = pair.Split(new char[] {':'});
            MethodInfo method = AccessTools.Method(game.GetType(parts[0], true), parts[1]);
            if (method == null) throw new MissingMethodException(pair);
            patcher.Patch(method, postfix: new HarmonyMethod(typeof(NativeObserver), "AfterNative"));
        }
        Logger.LogInfo("Read-only native observer loaded");
    }

    void Update()
    {
        if (String.IsNullOrEmpty(auditPath) || File.Exists(auditPath) || Time.realtimeSinceStartup < auditAt) return;
        auditAt = Time.realtimeSinceStartup + 1;
        try
        {
            Sample sample = new Sample();
            sample.binding = binding;
            sample.source = "DevelopmentResultAudit";
            sample.utc_seconds = (DateTime.UtcNow - new DateTime(1970,1,1)).TotalSeconds;
            sample.monotonic_seconds = (double)System.Diagnostics.Stopwatch.GetTimestamp() / System.Diagnostics.Stopwatch.Frequency;
            ReadStageResult(sample);
            if (sample.result_time_ms <= 0) return;
            using (FileStream file = new FileStream(auditPath, FileMode.CreateNew, FileAccess.Write))
            using (StreamWriter writer = new StreamWriter(file)) writer.Write(Serialize(sample));
        }
        catch (Exception e) { File.WriteAllText(auditPath + ".error", e.GetType().Name + ": " + e.Message); }
    }

    static void AfterNative(MethodBase __originalMethod, object __instance)
    {
        Sample s = new Sample();
        s.binding = binding;
        s.source = __originalMethod.DeclaringType.Name + "." + __originalMethod.Name;
        s.utc_seconds = (DateTime.UtcNow - new DateTime(1970,1,1)).TotalSeconds;
        s.monotonic_seconds = (double)System.Diagnostics.Stopwatch.GetTimestamp() / System.Diagnostics.Stopwatch.Frequency;
        s.unity_time = Time.time;
        s.delta_time = Time.deltaTime;
        s.fixed_time = Time.fixedTime;
        s.maximum_delta_time = Time.maximumDeltaTime;
        try
        {
            object ev = game.GetType("GameEntryPoint").GetProperty("EventManager", Flags).GetValue(null, null);
            if (ev == null) return;
            s.status = Convert.ToInt32(Field(ev,"status"));
            s.finish_gate = __originalMethod.DeclaringType.Name == "TimingGate" && Convert.ToBoolean(Field(__instance,"isFinishGate")) && s.status >= 5;
            s.debug = Convert.ToBoolean(Field(ev,"IsDebugWin"));
            object player = Field(ev,"playerManager");
            Rigidbody body = (Rigidbody)Field(player,"playerRigidBody");
            s.position = body.position;
            s.velocity = body.velocity;
            object route = Field(ev,"outOfBoundsManager");
            if (route == null) return;
            s.current = Convert.ToInt32(Field(route,"CurrentWaypointIndex"));
            s.start = Convert.ToInt32(Field(route,"StartingWaypointIndex"));
            s.last = Convert.ToInt32(Field(route,"LastWaypointIndex"));
            s.count = Convert.ToInt32(Field(route,"NumberOfWaypoints"));
            s.resetting = Convert.ToBoolean(Field(route,"isResettingInProgress"));
            object timer = Field(ev,"stageTimerManager");
            s.stage_time = Field(timer,"StageTime").ToString();
            s.penalties = Field(timer,"TotalTimePenalties").ToString();
            s.detected = Field(timer,"Detected").ToString();
            s.terminal_damage = Field(timer,"_isTerminalDamaged").ToString();
            ReadStageResult(s);
        }
        catch (Exception e) { s.error = e.GetType().Name + ": " + e.Message; }
        string signature = String.Join("|", new object[] {s.status, s.mode, s.stage, s.scene, s.weather, s.forward, s.current, s.start, s.last, s.count, s.resetting, s.debug, s.penalties, s.detected, s.terminal_damage, s.result_time_seconds_native, s.player_retired, s.error});
        bool routine = s.source == "OutOfBoundsManager.FixedUpdate" || s.source == "StageTimerManager.Update";
        if (routine && signature == lastSignature && s.monotonic_seconds - lastEmitted < 1.0) return;
        lastSignature = signature;
        lastEmitted = s.monotonic_seconds;
        s.sequence = ++sequence;
        output.WriteLine(Serialize(s));
    }
}
